"""System update routes for Bastet Gateway."""
import os
import json
import time
import threading

from fastapi import APIRouter, Depends, HTTPException

from config import (
    GATEWAY_UPDATE_FILE, ROBOT_UPDATE_FILE, ARDUINO_UPDATE_FILE,
    GITHUB_RELEASES_CACHE, STATE_FILE, load_json, save_json, manager,
)
from auth import verify_token
from models import UpdateProgress

router = APIRouter(tags=["System Updates"])


def get_cached_latest_release(repo: str, force: bool = False) -> str:
    """GitHub releases cache helper."""
    import requests
    now = time.time()
    if not force and repo in GITHUB_RELEASES_CACHE:
        tag, cached_time = GITHUB_RELEASES_CACHE[repo]
        if now - cached_time < 300:
            return tag
    try:
        url = f"https://api.github.com/repos/{repo}/releases/latest"
        headers = {"Accept": "application/vnd.github+json"}
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            headers["Authorization"] = f"token {token}"
        resp = requests.get(url, timeout=3, headers=headers)
        if resp.status_code == 200:
            tag = resp.json().get("tag_name", "v0.0.0")
            GITHUB_RELEASES_CACHE[repo] = (tag, now)
            return tag
    except Exception as e:
        print(f"Error fetching latest release for {repo}: {e}")
    if repo in GITHUB_RELEASES_CACHE:
        return GITHUB_RELEASES_CACHE[repo][0]
    return "v0.0.0"


@router.post("/system/update/gateway", summary="Lancer la mise à jour de la Gateway", dependencies=[Depends(verify_token)])
async def trigger_gateway_update():
    def run_up():
        try:
            from updater import check_and_apply_update
            save_json(GATEWAY_UPDATE_FILE, {"status": "starting", "percent": 0})
            updated = check_and_apply_update()
            if updated:
                import signal as sig
                save_json(GATEWAY_UPDATE_FILE, {"status": "done", "percent": 100})
                os.kill(os.getpid(), sig.SIGTERM)
            else:
                save_json(GATEWAY_UPDATE_FILE, {"status": "idle", "percent": 100})
        except Exception as e:
            save_json(GATEWAY_UPDATE_FILE, {"status": f"failed: {e}", "percent": 0})
    threading.Thread(target=run_up, daemon=True).start()
    return {"status": "triggered"}


@router.get("/system/update/gateway/progress", summary="Récupérer le progrès de mise à jour Gateway", dependencies=[Depends(verify_token)])
def get_gateway_update_progress(force: bool = False):
    progress = load_json(GATEWAY_UPDATE_FILE, default={"status": "idle", "percent": 100})
    if progress.get("status") not in ["idle", "failed"] and "failed" not in progress.get("status", "") and GATEWAY_UPDATE_FILE.exists():
        mtime = GATEWAY_UPDATE_FILE.stat().st_mtime
        if time.time() - mtime > 600:
            progress = {"status": "failed", "percent": 0, "error": "Timeout (10 min sans réponse)"}
            save_json(GATEWAY_UPDATE_FILE, progress)
    from updater import get_current_version
    progress["current_version"] = get_current_version()
    progress["latest_version"] = get_cached_latest_release("Bot-Bastet/CORE-Gateway", force=force)
    return progress


@router.post("/system/update/gateway/progress", summary="Mettre à jour le progrès Gateway", dependencies=[Depends(verify_token)])
async def update_gateway_progress(progress: UpdateProgress):
    data = progress.model_dump()
    save_json(GATEWAY_UPDATE_FILE, data)
    await manager.broadcast(json.dumps({"type": "gateway_update_progress", **data}), "app")
    return {"status": "ok"}


@router.post("/system/update/robot", summary="Lancer la mise à jour du robot", dependencies=[Depends(verify_token)])
async def trigger_robot_update():
    initial = {"status": "starting", "percent": 0}
    save_json(ROBOT_UPDATE_FILE, initial)
    await manager.broadcast(json.dumps({"type": "robot_update_progress", **initial}), "app")
    await manager.broadcast(json.dumps({"type": "trigger_update"}), "robot")
    return {"status": "triggered"}


@router.post("/system/update/robot/progress", summary="Mettre à jour le progrès du robot", dependencies=[Depends(verify_token)])
async def update_robot_progress(progress: UpdateProgress):
    data = progress.model_dump()
    save_json(ROBOT_UPDATE_FILE, data)
    await manager.broadcast(json.dumps({"type": "robot_update_progress", **data}), "app")
    return {"status": "ok"}


@router.get("/system/update/robot/progress", summary="Récupérer le progrès de mise à jour robot", dependencies=[Depends(verify_token)])
def get_robot_update_progress(force: bool = False):
    progress = load_json(ROBOT_UPDATE_FILE, default={"status": "idle", "percent": 100})
    if progress.get("status") not in ["idle", "failed"] and "failed" not in progress.get("status", "") and ROBOT_UPDATE_FILE.exists():
        mtime = ROBOT_UPDATE_FILE.stat().st_mtime
        if time.time() - mtime > 60:
            progress = {"status": "failed", "percent": 0, "error": "Timeout (60 s sans progrès)"}
            save_json(ROBOT_UPDATE_FILE, progress)
    state = load_json(STATE_FILE, default={})
    if not isinstance(state, dict):
        state = {}
    progress["current_version"] = state.get("robot_version", "v0.0.0")
    progress["latest_version"] = get_cached_latest_release("Bot-Bastet/CORE", force=force)
    return progress


@router.post("/system/update/arduino", summary="Lancer la mise à jour de l'Arduino", dependencies=[Depends(verify_token)])
async def trigger_arduino_update():
    initial = {"status": "starting", "percent": 0}
    save_json(ARDUINO_UPDATE_FILE, initial)
    await manager.broadcast(json.dumps({"type": "arduino_update_progress", **initial}), "app")
    await manager.broadcast(json.dumps({"type": "trigger_arduino_flash"}), "robot")
    return {"status": "triggered"}


@router.post("/system/update/arduino/progress", summary="Mettre à jour le progrès de l'Arduino", dependencies=[Depends(verify_token)])
async def update_arduino_progress(progress: UpdateProgress):
    data = progress.model_dump()
    save_json(ARDUINO_UPDATE_FILE, data)
    await manager.broadcast(json.dumps({"type": "arduino_update_progress", **data}), "app")
    return {"status": "ok"}


@router.get("/system/update/arduino/progress", summary="Récupérer le progrès de mise à jour Arduino", dependencies=[Depends(verify_token)])
def get_arduino_update_progress(force: bool = False):
    progress = load_json(ARDUINO_UPDATE_FILE, default={"status": "idle", "percent": 100})
    if progress.get("status") not in ["idle", "failed"] and "failed" not in progress.get("status", "") and ARDUINO_UPDATE_FILE.exists():
        mtime = ARDUINO_UPDATE_FILE.stat().st_mtime
        if time.time() - mtime > 60:
            progress = {"status": "failed", "percent": 0, "error": "Timeout (60 s sans progrès)"}
            save_json(ARDUINO_UPDATE_FILE, progress)
    state = load_json(STATE_FILE, default={})
    if not isinstance(state, dict):
        state = {}
    progress["current_version"] = state.get("arduino_version", "v0.0.0")
    progress["latest_version"] = get_cached_latest_release("Bot-Bastet/CORE", force=force)
    return progress


@router.post("/system/update/gateway/rollback", summary="Rollback Gateway to a specific release", dependencies=[Depends(verify_token)])
async def trigger_gateway_rollback(data: dict):
    version = data.get("version", "")
    if not version:
        raise HTTPException(status_code=400, detail="Version required")
    def run_rollback():
        try:
            save_json(GATEWAY_UPDATE_FILE, {"status": "rollback_starting", "percent": 0, "version": version})
            from updater import apply_specific_release
            apply_specific_release(version)
            save_json(GATEWAY_UPDATE_FILE, {"status": "done", "percent": 100})
            import signal as sig
            os.kill(os.getpid(), sig.SIGTERM)
        except Exception as e:
            save_json(GATEWAY_UPDATE_FILE, {"status": f"failed: {e}", "percent": 0})
    threading.Thread(target=run_rollback, daemon=True).start()
    return {"status": "triggered", "version": version}


@router.post("/system/update/robot/rollback", summary="Rollback Robot + Arduino to a specific release", dependencies=[Depends(verify_token)])
async def trigger_robot_rollback(data: dict):
    version = data.get("version", "")
    if not version:
        raise HTTPException(status_code=400, detail="Version required")
    initial = {"status": "rollback_starting", "percent": 0, "version": version}
    save_json(ROBOT_UPDATE_FILE, initial)
    await manager.broadcast(json.dumps({"type": "robot_update_progress", **initial}), "app")
    await manager.broadcast(json.dumps({"type": "trigger_update", "version": version}), "robot")
    await manager.broadcast(json.dumps({"type": "trigger_arduino_flash", "version": version}), "robot")
    return {"status": "triggered", "version": version}
